import { AngularproPage } from './app.po';

describe('angularpro App', () => {
  let page: AngularproPage;

  beforeEach(() => {
    page = new AngularproPage();
  });

  it('should display welcome message', done => {
    page.navigateTo();
    page.getParagraphText()
      .then(msg => expect(msg).toEqual('Welcome to app!!'))
      .then(done, done.fail);
  });
});
